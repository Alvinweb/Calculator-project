function displaykey(input){
 document.getElementById('display')
 display.value += input;
};

function Calculate(){
    display.value =eval(display.value);
};

function ClearDisplay(){
    display.value = ""
}


